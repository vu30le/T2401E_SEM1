angular.module('app', []);

angular.module('app').controller("MainController", function(){
    var vm = this;
    vm.title = 'A list of Books';
    vm.searchInput = '';
    vm.shows = [
        {
             title: 'Life of Pi',
            author: 'Davan',
            year: 2001
        },
        {
             title: 'Học code totay',
            author: 'Fpt',
            year: 2024
        },
        {
             title: 'Learn Angular by example',
            author: 'Fpt-Aptech',
            year: 2024
        },
        {
            title: 'Họ nhà trai',
            author: 'Nguyễn Anh Tú',
            year: 2024
        },
        {
             title: 'Đôi mắt có lửa',
            author: 'Nguyễn Hùng Sơn',
            year: 2024
        }
    ];
    vm.orders = [
        {
            id: 1,
            title: 'Author Ascending',
            key: 'author',
            reverse: false
        },
        {
            id: 2,
            title: 'Author Descending',
            key: 'author',
            reverse: true
        },
        {
            id: 3,
            title: 'Title Ascending',
            key: 'title',
            reverse: false
        },
        {
            id: 4,
            title: 'Title Descending',
            key: 'title',
            reverse: true
        },
        {
            id: 5,
            title: 'Year Ascending',
            key: 'year',
            reverse: false
        },
        {
            id: 6,
            title: 'Year Descending',
            key: 'year',
            reverse: true
        }
    ];
    vm.order = vm.orders[0];
    vm.new = {};
    vm.addShow = function() {
        vm.shows.push(vm.new);
        vm.new = {};
    };
});