import { useState } from "react";
function FormEvent () {
    const sexs = [{id:1, value:"Male"},{id:2, value:"Female"},{id:3, value:"Other"}]
    const jobs = [{id:1, value:"IT"},{id:2, value:"Sale"},{id:3, value:"Marketing"}]
    const [name, setName] = useState("")
    const [sex, setSex] = useState()
    const [job, setJob] = useState([])
    const [select, setSelect] = useState(1)

    const handleJob = (id) => {
        setJob(prev => {
            const isSelected = job.includes(id)

            if (isSelected) {
                return job.filter(item => item != id);
            } else {
                return [...prev, id]
            }
        })
    }
    
    const handleSubmit = () => {
        console.log(name)
        console.log(sex)
        console.log(job)
        console.log(select) 
    }

    return(
        <>
            <div>
                <label>Name</label>
                <input 
                type="text" 
                style={{width:300}}
                onChange={e => setName(e.target.value)}
                >

                </input>
            </div>
            <div>
                {sexs.map(item => (
                    <div key={item.id}>
                        <input 
                            type="radio"
                            onChange={() => setSex(item.id)}
                            checked = {sex === item.id}
                        />
                        {item.value}
                    </div>
                ))}
            </div>

            <div>
                {jobs.map(item => (
                    <div key={item.id}>
                        <input 
                            type="checkbox"
                            onChange={() => handleJob(item.id)}
                            checked = {job.includes(item.id)}
                        />
                        {item.value}
                    </div>
                ))}
            </div>

            <div>
                <select onChange={e => setSelect(e.target.value)} value={select}>
                    {jobs.map(item => (
                        <option key={item.id} value={item.id}>
                            {item.value}
                        </option>
                    ))}
                </select>
            </div>
            <button onClick={handleSubmit}>Submit</button>
        </>
    )
}

export default FormEvent;