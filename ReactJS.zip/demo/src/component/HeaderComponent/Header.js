import { Link } from "react-router-dom"
function Header() {
    return (
        <>
        <li><Link to ="/">Home</Link></li>
        <li><Link to ="/Products">Products</Link></li>
        <li><Link to ="/Contact">Contact</Link></li>
        </>
    )
}
export default Header