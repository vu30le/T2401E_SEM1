function Footer() {
    return(
        <>Footer</>
    )
}
export default Footer