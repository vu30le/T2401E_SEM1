function App() {
  return (
<>
  <meta charSet="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="login.css" />
  <link rel="stylesheet" href="reponsive.css" />
  <link rel="stylesheet" href="HOME.css" />
  <link rel="stylesheet" href="responsive_content.css" />
  <link
    rel="icon"
    href="//bizweb.dktcdn.net/100/363/455/themes/918830/assets/favicon.png?1704690471681"
    type="image/x-icon"
  />
  <link
    href="https://cdn.jsdelivr.net/gh/eliyantosarage/font-awesome-pro@main/fontawesome-pro-6.5.1-web/css/all.min.css"
    rel="stylesheet"
  />
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
  />
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
  />
  <title>Nha Nam</title>
  <header>
    <div className="grid wide">
      <div className="container row">
        <div className="col c-0 m-0 l-1">
          <a href="nhanam1.html">
            <img src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/logo.png?1704690471681" />
          </a>
        </div>
        <div className="col c-0 m-6 l-0">
          <div
            className="header_content"
            style={{ justifyContent: "flex-start" }}
          >
            <i className="fa-solid fa-bars fa-2x theme_color" />
            <a href="nhanam1.html">
              <img src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/logo.png?1704690471681" />
            </a>
          </div>
        </div>
        <div className="col c-12 m-0 l-0">
          <div className="header_content">
            <i className="fa-solid fa-bars fa-2x theme_color" />
            <a className="header_content" href="nhanam1.html">
              <img src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/logo.png?1704690471681" />
            </a>
            <div className="header_content">
              <i className="fa-solid fa-magnifying-glass dropdown">
                <form className="header_search">
                  <input type="text" placeholder="Tìm kiếm..." required="" />
                  <button
                    type="submit"
                    className="fa-solid fa-magnifying-glass"
                  />
                </form>
              </i>
              <i
                className="fa-regular fa-bag-shopping fa-lg icon"
                style={{ position: "relative" }}
              >
                <div className="item_counter_box">
                  <div className="item_counter">0</div>
                </div>
              </i>
            </div>
          </div>
        </div>
        <div className="c-0 m-0 l-8">
          <ul className="header_content">
            <li>
              <a href="nhanam1.html">Trang chủ</a>
            </li>
            <li className="dropdown">
              <a className="list" href="https://nhanam.vn/lien-he">
                Tin sách
              </a>
              <div className="dropdown_list" style={{ minWidth: 250 }}>
                <a href="https://nhanam.vn/tin-nha-nam">Tin Nhã Nam</a>
                <a href="https://nhanam.vn/tin-nha-nam">
                  Review sách của độc giả
                </a>
                <a href="https://nhanam.vn/tin-nha-nam">
                  Review sách trên báo chí
                </a>
                <a href="https://nhanam.vn/tin-nha-nam">
                  Biên tập viên giới thiệu
                </a>
              </div>
            </li>
            <li className="dropdown">
              <a className="list" href="https://nhanam.vn/collections/all">
                Sách Nhã Nam
              </a>
              <div className="dropdown_table">
                <div className="tablecol">
                  <h3>
                    <a href="#">Hư cấu</a>
                    <div className="h3underline" />
                  </h3>
                  <a href="#">Văn học hiện đại</a>
                  <a href="#">Văn học kinh điển</a>
                  <a href="#">Văn học thiếu nhi</a>
                  <a href="#"> Lãng mạn</a>
                  <a href="#">Kỳ ảo</a>
                  <a href="#">Trinh thám - Kinh dị</a>
                  <a href="#">Khoa học Viễn tưởng</a>
                  <a href="#">Phiêu lưu ly kỳ</a>
                  <a href="#">Tản văn</a>
                  <a href="#">Truyện tranh (Graphic novel)</a>
                  <a href="#">Sách tranh (Picture book)</a>
                  <a href="#">Thơ - kịch</a>
                  <a href="#">Light novel</a>
                  <a href="#">Sách tô màu</a>
                </div>
                <div className="tablecol">
                  <h3>
                    <a href="#">Phi hư cấu</a>
                    <div className="h3underline" />
                  </h3>
                  <a href="#">Triết học</a>
                  <a href="#">Sử học</a>
                  <a href="#">Khoa học</a>
                  <a href="#">Kinh doanh</a>
                  <a href="#">Kinh tế chính trị</a>
                  <a href="#">Kỹ năng </a>
                  <a href="#">Nghệ thuật</a>
                  <a href="#">Nuôi dạy con</a>
                  <a href="#">Tiểu luận - phê bình</a>
                  <a href="#">Tâm lý ứng dụng</a>
                  <a href="#">Tâm lý học</a>
                  <a href="#">Hồi ký</a>
                  <a href="#">Y học - Sức khỏe</a>
                  <a href="#">Tâm linh - Tôn giáo</a>
                  <a href="#">Kiến thức phổ thông</a>
                  <a href="#">Phong cách sống</a>
                </div>
                <div className="tablecol">
                  <h3>
                    <a href="#">Thiếu nhi</a>
                    <div className="h3underline" />
                  </h3>
                  <a href="#">0-5 tuổi</a>
                  <a href="#">6-8 tuổi</a>
                  <a href="#">9-12 tuổi</a>
                  <a href="#">13-15 tuổi</a>
                </div>
                <div className="tablecol">
                  <h3>
                    <a href="#">Phân loại khác</a>
                    <div className="h3underline" />
                  </h3>
                  <a href="#">Sách bán chạy</a>
                  <a href="#">Sách mới xuất bản</a>
                  <a href="#">Sách sắp xuất bản</a>
                  <a href="#">Sách được giải thưởng</a>
                  <a href="#">Sách pop-up, lift-the-flaps</a>
                  <a href="#">Nghiên cứu Việt Nam</a>
                  <a href="#">Việt Nam danh tác</a>
                  <a href="#">Tác giả Việt Nam</a>
                  <a href="#">Bản đặc biệt</a>
                  <a href="#">Phụ kiện - Quà tặng</a>
                </div>
              </div>
            </li>
            <li>
              <a href="https://nhanam.vn/tac-gia">Tác giả</a>
            </li>
            <li className="dropdown">
              <a className="list" href="https://nhanam.vn/cuoc-thi">
                Cuộc thi
              </a>
              <div className="dropdown_list" style={{ minWidth: 250 }}>
                <a href="https://nhanam.vn/tin-nha-nam">AI ĐÓ ĐỌC CÙNG TA</a>
              </div>
            </li>
            <li>
              <a href="https://nhanam.vn/gioi-thieu">Về Nhã Nam</a>
            </li>
            <li className="dropdown">
              <a className="list" href="https://nhanam.vn/lien-he">
                Liên hệ
              </a>
              <div className="dropdown_list" style={{ minWidth: 250 }}>
                <a href="https://nhanam.vn/tin-nha-nam">Hệ thống hiệu sách</a>
                <a href="https://nhanam.vn/tin-nha-nam">Hệ thống phát hành</a>
                <a href="https://nhanam.vn/tin-nha-nam">Gửi thư cho Nhã Nam</a>
                <a href="https://nhanam.vn/tin-nha-nam">Tuyển dụng</a>
              </div>
            </li>
          </ul>
        </div>
        {/* <div class="col c-8 m-0 l-0"> */}
        {/* </div> */}
        <div className="col c-0 m-0 l-3">
          <div className="header_content">
            <form className="header_search">
              <input type="text" placeholder="Tìm kiếm..." required="" />
              <button type="submit" className="fa-solid fa-magnifying-glass" />
            </form>
            <i className="fa-regular fa-user fa-lg icon dropdown">
              <div className="dropdown_list">
                <a href="login.html">Đăng nhập</a>
                <a href="register.html">Đăng ký</a>
              </div>
            </i>
            <i
              className="fa-regular fa-bag-shopping fa-lg icon"
              style={{ position: "relative" }}
            >
              <div className="item_counter_box">
                <div className="item_counter">0</div>
              </div>
            </i>
          </div>
        </div>
        {/* <div class="col c-0 m-4 l-0"></div> */}
        <div className="col c-0 m-6 l-0">
          <div className="header_content">
            <form className="header_search">
              <input type="text" placeholder="Tìm kiếm..." required="" />
              <button type="submit" className="fa-solid fa-magnifying-glass" />
            </form>
            <div className="header_content">
              <i className="fa-regular fa-user fa-lg icon dropdown">
                <div className="dropdown_list">
                  <a href="../html/login.html">Đăng nhập</a>
                  <a href="../html/login.html">Đăng ký</a>
                </div>
              </i>
              <i
                className="fa-regular fa-bag-shopping fa-lg icon"
                style={{ position: "relative" }}
              >
                <div className="item_counter_box">
                  <div className="item_counter">0</div>
                </div>
              </i>
            </div>
          </div>
        </div>
        {/* <div class="col c-2 m-0 l-0">
          </div>                */}
      </div>
    </div>
  </header>
  <div className="content-1">
    <div className="grid wide">
      <div className="row">
        <div className="col l-8 m-12 c-12 blog">
          <a href="">
            <img
              src="https://bizweb.dktcdn.net/100/363/455/articles/trang-web-9c2872f3-c1e8-4f4d-8706-07845b72e362.png?v=1710132804897"
              alt=""
            />
          </a>
          <div className="content-blog main-content">
            <h3 className="one">
              <a href="" className="a-title">
                Cơ hội gặp gỡ một trong những nhà văn Pháp đương đại nổi tiếng
                nhất
              </a>
            </h3>
            <span style={{ fontSize: 14, color: "#7B7B7D" }}>
              Thứ 3, 12/03/2024
            </span>
          </div>
        </div>
        <div className="col l-4 m-12 c-12">
          <div className="blog-list">
            <div className="item" style={{ paddingTop: 0 }}>
              <div className="item-blog">
                <a href="" className="thumb">
                  <img
                    src="https://bizweb.dktcdn.net/100/363/455/articles/seo-2.png?v=1700487959943"
                    alt=""
                    className="img-blog"
                  />
                </a>
                <div className="content-blog-2">
                  <h3 style={{ marginBottom: 10 }}>
                    <a
                      href=""
                      title="5 bí quyết dưỡng ẩm đắt giá - Chăm sóc da hiệu quả ngay trong mùa"
                    >
                      5 bí quyết dưỡng ẩm đắt giá - Chăm sóc da hiệu quả ngay
                      trong mùa đông
                    </a>
                  </h3>
                  <span style={{ fontSize: 14, color: "#7B7B7D" }}>
                    Thứ Hai, 20/11/2023
                  </span>
                </div>
              </div>
            </div>
            <div className="item">
              <div className="item-blog">
                <a href="" className="thumb">
                  <img
                    src="https://bizweb.dktcdn.net/100/363/455/articles/seo-1.png?v=1700281321867"
                    alt=""
                    className="img-blog"
                  />
                </a>
                <div className="content-blog-2">
                  <h3 style={{ marginBottom: 10 }}>
                    <a
                      href=""
                      title="Khám phá bí mật làm thịt lợn quay bì giòn tại gia"
                    >
                      Khám phá bí mật làm thịt lợn quay bì giòn tại gia
                    </a>
                  </h3>
                  <span style={{ fontSize: 14, color: "#7B7B7D" }}>
                    Thứ Bảy, 18/11/2023
                  </span>
                </div>
              </div>
            </div>
            <div className="item">
              <div className="item-blog">
                <a href="" className="thumb">
                  <img
                    src="https://bizweb.dktcdn.net/100/363/455/articles/nha-nam-website-3154da6f-42a3-4ff9-b4c5-f7b217989147.png?v=1699532816857"
                    alt=""
                    className="img-blog"
                  />
                </a>
                <div className="content-blog-2">
                  <h3 style={{ marginBottom: 10 }}>
                    <a href="" title="Những cuốn sách dành cho người hướng nội">
                      Những cuốn sách dành cho người hướng nội
                    </a>
                  </h3>
                  <span style={{ fontSize: 14, color: "#7B7B7D" }}>
                    Thứ Năm, 09/11/2023
                  </span>
                </div>
              </div>
            </div>
            <div className="item" style={{ border: "none" }}>
              <div className="item-blog">
                <a href="" className="thumb">
                  <img
                    src="https://bizweb.dktcdn.net/100/363/455/articles/ban-do-cf.png?v=1698399264317"
                    alt=""
                    className="img-blog"
                  />
                </a>
                <div className="content-blog-2">
                  <h3 style={{ marginBottom: 10 }}>
                    <a
                      href=""
                      title="Sự thật ám ảnh về loại cafe đắt nhất thế giới"
                    >
                      Sự thật ám ảnh về loại cafe đắt nhất thế giới
                    </a>
                  </h3>
                  <span style={{ fontSize: 14, color: "#7B7B7D" }}>
                    Thứ Sáu, 27/10/2023
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div className="grid wide">
    <div className="content-2">
      {/* top content 2*/}
      <div className="top-content-2">
        <h1>Các tác giả</h1>
        <a href="" className="seen-more">
          <h3>Xem thêm</h3>
          <i className="fa fa-angle-right" />
        </a>
      </div>
      {/* below content 2*/}
      <div className="below-content-2">
        <a href="" className=" container-item-content-2">
          <div>
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/du-6-au-8-avril-on-pourra-rencontrer-caryl-ferey-a-quais-du-polar-plus-jamais-seul-est-en-lice-pour-le-prix-polar-en-serie-photo-d-archives-pierre-augros-1522611099.jpeg?v=1705585948700"
                alt="Caryl Férey"
                title="Caryl Férey"
              />
            </li>
          </div>
          <h3 className="hover-name-tacgia">Caryl Férey</h3>
        </a>
        <a href="" className=" container-item-content-2">
          <div>
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/a001157172-23.jpeg?v=1705927222763"
                alt="Urakami Tetsuya"
                title="Urakami Tetsuya"
              />
            </li>
          </div>
          <h3 className="hover-name-tacgia">Urakami Tetsuya</h3>
        </a>
        <a href="" className="item-2 container-item-content-2">
          <div>
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/lightman.jpeg?v=1705296925087"
                alt="Alan Lightman"
                title="Alan Lightman"
              />
            </li>
          </div>
          <h3 className="hover-name-tacgia">Alan Lightman</h3>
        </a>
        <a href="" className="item-3 container-item-content-2">
          <div>
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/perec.jpg?v=1705299179727"
                alt="Georges Perec"
                title="Georges Perec"
              />
            </li>
          </div>
          <h3 className="hover-name-tacgia">Georges Perec</h3>
        </a>
        <a href="" className="item-4 container-item-content-2">
          <div>
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/blank-author-3e2f8612-a184-47e9-bc7b-97528e3d8c32.jpg?v=1705288131493"
                alt="Lee Jin Song"
                title="Lee Jin Song"
              />
            </li>
          </div>
          <h3 className="hover-name-tacgia">Lee Jin Song</h3>
        </a>
        <a href="" className="item-5 container-item-content-2">
          <div>
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/blank-author-33728236-0ca7-4f4e-a265-ddcd14036f53.jpg?v=1705287921247"
                alt="Nhóm tư vấn Từ Mạn Mạn"
                title="Nhóm tư vấn Từ Mạn Mạn"
              />
            </li>
          </div>
          <h3 className="hover-name-tacgia">Nhóm tư vấn Từ Mạn Mạn</h3>
        </a>
      </div>
    </div>
    {/* content 3 */}
    <div className="content-3">
      {/* top content 3*/}
      <div className="top-content-3">
        <h1>Sách mới</h1>
        <a href="" className="seen-more">
          <h3>Xem thêm</h3>
          <i className="fa fa-angle-right" />
        </a>
      </div>
      {/* below content 3 */}
      <div className="below-content-3">
        <a href="nhanam2.html" className="pic pic-content-3-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/khong-co-tuyet-vong-tren-instagram-01-e1710474202548.jpg?v=1710474211207"
              alt="KHÔNG CÓ TUYỆT VỌNG TRÊN INSTAGRAM"
              title="KHÔNG CÓ TUYỆT VỌNG TRÊN INSTAGRAM"
            />
            <div className="buy-cart">
              <div className="cart">
                <i className="fa fa-shopping-bag" />
              </div>
              <div className="buy">Mua ngay</div>
            </div>
          </li>
          <div className="book-name-price">
            <h3 className="hover-name-book">
              KHÔNG CÓ TUYỆT VỌNG TRÊN INSTAGRAM
            </h3>
            <div className="price-book">
              <h3 className="price">123.250₫</h3>
              <del>145.000₫</del>
            </div>
          </div>
        </a>
        <a href="" className="pic pic-content-3-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/thuc-hanh-khac-ky-01-e1710211043565.jpg?v=1710211104237"
              alt="THỰC HÀNH KHẮC KỶ"
              title="THỰC HÀNH KHẮC KỶ"
            />
            <div className="buy-cart">
              <div className="cart">
                <i className="fa fa-shopping-bag" />
                <i className="fas fs-shop" />
              </div>
              <div className="buy">Mua ngay</div>
            </div>
          </li>
          <div className="book-name-price">
            <h3 className="hover-name-book">THỰC HÀNH KHẮC KỶ</h3>
            <div className="price-book">
              <h3 className="price">91.800₫</h3>
              <del>108.000₫</del>
            </div>
          </div>
        </a>
        <a href="" className="pic-2 pic-content-3-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/tieng-thet-cam-lang-01-e1710210545189.jpg?v=1710210558077"
              alt="TIẾNG THÉT CÂM LẶNG"
              title="TIẾNG THÉT CÂM LẶNG"
            />
            <div className="buy-cart">
              <div className="cart">
                <i className="fa fa-shopping-bag" />
                <i className="fas fs-shop" />
              </div>
              <div className="buy">Mua ngay</div>
            </div>
          </li>
          <div className="book-name-price">
            <h3 className="hover-name-book">TIẾNG THÉT CÂM LẶNG</h3>
            <div className="price-book">
              <h3 className="price">212.500₫</h3>
              <del>250.000₫</del>
            </div>
          </div>
        </a>
        <a href="" className="pic-3 pic-content-3-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/chang-trai-chuyen-kiep-va-co-gai-thien-tai-2-01-e1709006845284.jpg?v=1709006861020"
              alt="CHÀNG TRAI CHUYỂN KIẾP VÀ CÔ GÁI THIÊN TÀI TẬP 2"
              title="CHÀNG TRAI CHUYỂN KIẾP VÀ CÔ GÁI THIÊN TÀI TẬP 2"
            />
            <div className="buy-cart">
              <div className="cart">
                <i className="fa fa-shopping-bag" />
                <i className="fas fs-shop" />
              </div>
              <div className="buy">Mua ngay</div>
            </div>
          </li>
          <div className="book-name-price">
            <h3 className="hover-name-book">
              CHÀNG TRAI CHUYỂN KIẾP VÀ CÔ GÁI THIÊN TÀI TẬP 2
            </h3>
            <div className="price-book">
              <h3 className="price">114.750₫</h3>
              <del>135.000₫</del>
            </div>
          </div>
        </a>
        <a href="" className="pic-4 pic-content-3-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/tuoigiarucroe1708260434879.jpg?v=1708261482417"
              alt="TUỔI GIÀ RỰC RỠ"
              title="TUỔI GIÀ RỰC RỠ"
            />
            <div className="buy-cart">
              <div className="cart">
                <i className="fa fa-shopping-bag" />
                <i className="fas fs-shop" />
              </div>
              <div className="buy">Mua ngay</div>
            </div>
          </li>
          <div className="book-name-price">
            <h3 className="hover-name-book">TUỔI GIÀ RỰC RỠ</h3>
            <div className="price-book">
              <h3 className="price">254.150₫</h3>
              <del>299.000₫</del>
            </div>
          </div>
        </a>
      </div>
      {/* bottom content 3 */}
      <div className="bottom-content-3">
        {/* left conntent 3 */}
        <div className="left-content-3">
          <h1>Nhã Nam</h1>
          <i>Bởi vì sách là thế giới</i>
          <p>
            Nhã Nam, tên đầy đủ là Công ty Cổ phần Văn hóa và Truyền thông Nhã
            Nam, gia nhập thị trường sách Việt Nam vào tháng 2 năm 2005. Ngay từ
            cuốn sách đầu tiên, độc giả đã dành sự quan tâm và yêu mến cho một
            thương hiệu sách mới mẻ mang trong mình khát vọng góp phần tạo lập
            diện mạo mới cho xuất bản văn học tại Việt Nam.
          </p>
          <a href="" className="hover-click-XemThem">
            <h3>Xem thêm</h3>
          </a>
        </div>
        {/* right content 3 */}
        <div className="right-content-3">
          <img
            src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/banner-module-profile.jpg?1704690471681"
            alt="anh"
          />
        </div>
      </div>
    </div>
    {/* Content 4 */}
    <div className="content-4">
      {/* top content 4 */}
      <div className="top-content-4">
        <h1>Sách Nhã Nam trên báo chí</h1>
        <a href="" className="seen-more">
          <h3>Xem thêm</h3>
          <i className="fa fa-angle-right" />
        </a>
      </div>
      {/* bottom content 4 */}
      <div className="bottom-content-4">
        <a href="" className="click click-content-4-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/mot-ngay-trong-doi-ivan-denisovich-01-e1710382608466.jpg?v=1710382664393"
              alt="MỘT NGÀY TRONG ĐỜI IVAN DENISOVICH"
              title="MỘT NGÀY TRONG ĐỜI IVAN DENISOVICH"
            />
          </li>
          <div className="infor-book-content-4">
            <p className="name-book-content-4">
              MỘT NGÀY TRONG ĐỜI IVAN DENISOVICH
            </p>
            <div className="bottom-infor price-book-content-4">
              <p>127.500₫</p>
              <small>
                <del>150.000₫</del>
              </small>
            </div>
          </div>
        </a>
        <a href="" className="click click-content-4-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/hoi-dap-cung-em-tuong-lai-se-the-nao-c-04.jpg?v=1710382343007"
              alt="HỎI ĐÁP CÙNG EM - TƯƠNG LAI SẼ THẾ NÀO?"
              title="HỎI ĐÁP CÙNG EM - TƯƠNG LAI SẼ THẾ NÀO?"
            />
          </li>
          <div className="infor-book-content-4">
            <p className="name-book-content-4">
              HỎI ĐÁP CÙNG EM - TƯƠNG LAI SẼ THẾ NÀO?
            </p>
            <p>Xem thêm</p>
          </div>
        </a>
        <a href="" className="click-2 click-content-4-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/meo-chien-binh-thoi-khac-tam-toi-01-e1710382055163.jpg?v=1710382063447"
              alt="MÈO CHIẾN BINH 6 - THỜI KHẮC TĂM TỐI"
              title="MÈO CHIẾN BINH 6 - THỜI KHẮC TĂM TỐI"
            />
          </li>
          <div className="infor-book-content-4">
            <p className="name-book-content-4">
              MÈO CHIẾN BINH 6 - THỜI KHẮC TĂM TỐI
            </p>
            <p>Xem thêm</p>
          </div>
        </a>
        <a href="" className="click-3 click-content-4-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/truoc-khi-chung-ta-noi-loi-chia-tay-01-e1709778991248.jpg?v=1709779093920"
              alt="TRƯỚC KHI CHÚNG TA NÓI LỜI CHIA TAY"
              title="TRƯỚC KHI CHÚNG TA NÓI LỜI CHIA TAY"
            />
          </li>
          <div className="infor-book-content-4">
            <p className="name-book-content-4">
              TRƯỚC KHI CHÚNG TA NÓI LỜI CHIA TAY
            </p>
            <p>Xem thêm</p>
          </div>
        </a>
        <a href="" className="click-4 click-content-4-hover">
          <li>
            <img
              src="https://bizweb.dktcdn.net/thumb/large/100/363/455/products/tram-cam-va-ky-nang-tu-kiem-soat-tram-cam-01-e1709778785909.jpg?v=1709778898463"
              alt="TRẦM CẢM VÀ KỸ NĂNG TỰ KIỂM SOÁT TRẦM CẢM"
              title="TRẦM CẢM VÀ KỸ NĂNG TỰ KIỂM SOÁT TRẦM CẢM"
            />
          </li>
          <div className="infor-book-content-4">
            <p className="name-book-content-4">
              TRẦM CẢM VÀ KỸ NĂNG TỰ KIỂM SOÁT TRẦM CẢM
            </p>
            <p>Xem thêm</p>
          </div>
        </a>
      </div>
    </div>
    {/* content 5 */}
    <div className="content-5">
      {/* top content 5 */}
      <div className="top-content-5">
        <h1>Sách Nhã Nam trên báo chí</h1>
        <a href="" className="seen-more">
          <h3>Xem thêm</h3>
          <i className="fa fa-angle-right" />
        </a>
      </div>
      {/* bottom content 5 */}
      <div className="bottom-content-5">
        <div className="container-item-content-5">
          <a href="">
            <img
              src="https://bizweb.dktcdn.net/100/363/455/articles/website-a-nh-da-i-die-n-ba-i-vie-t-12.png?v=1710848741370"
              alt="Gặp gỡ nhà văn Pháp Bernard Werber: Xã hội loài người chỉ 1/3 thật sự làm việc"
              title="Gặp gỡ nhà văn Pháp Bernard Werber: Xã hội loài người chỉ 1/3 thật sự làm việc"
            />
            <p className="text-bottom-content-5">
              Gặp gỡ nhà văn Pháp Bernard Werber: Xã hội loài người chỉ 1/3 thật
              sự làm việc
            </p>
          </a>
          <p>
            Trò chuyện với độc giả Hà Nội vàp ngày 16/3 nhân chuyến thăm và giao
            lưu với độc giả ba...
          </p>
          <p className="date-bottom-content-5">Thứ Ba, 19/03/2024</p>
        </div>
        <div className="container-item-content-5">
          <a href="">
            <img
              src="https://bizweb.dktcdn.net/100/363/455/articles/website-a-nh-da-i-die-n-ba-i-vie-t-7.png?v=1710232983947"
              alt="Độc giả Việt từng không mấy mặn mà với Xứ cát"
              title="Độc giả Việt từng không mấy mặn mà với Xứ cát"
            />
            <p className="text-bottom-content-5">
              Độc giả Việt từng không mấy mặn mà với "Xứ cát"
            </p>
          </a>
          <p>
            "Xứ cát" không ngoại lệ với các sách khác thuộc dòng kinh điển của
            thể loại khoa học viễn tưởng,...
          </p>
          <p className="date-bottom-content-5">Thứ Ba, 12/03/2024</p>
        </div>
        <div className="item-content-5-2 container-item-content-5">
          <a href="">
            <img
              src="https://bizweb.dktcdn.net/100/363/455/articles/website-a-nh-da-i-die-n-ba-i-vie-t-4.png?v=1710229061890"
              alt="Tiểu luận về nghệ thuật An Nam: Bức tranh tổng quát về mỹ thuật, kiến trúc, nghi lễ văn hoá Việt Nam"
              title="Tiểu luận về nghệ thuật An Nam: Bức tranh tổng quát về mỹ thuật, kiến trúc, nghi lễ văn hoá Việt Nam"
            />
            <p className="text-bottom-content-5">
              Tiểu luận về nghệ thuật An Nam: Bức tranh tổng quát về mỹ thuật,
              kiến trúc, nghi lễ văn hoá Việt Nam
            </p>
          </a>
          <p>
            ANTD.VN - Bản dịch tiếng Việt tác phẩm "Tiểu luận về nghệ thuật An
            Nam" của tác giả Louis Bezacier...
          </p>
          <p className="date-bottom-content-5">Thứ Ba, 12/03/2024</p>
        </div>
      </div>
    </div>
    {/* content 6 */}
    <div className="content-6">
      {/* top-content-6 */}
      <div className="top-content-6">
        <h1>Các đối tác</h1>
        <a href="" className="seen-more">
          <h3>Xem thêm</h3>
          <i className="fa fa-angle-right" />
        </a>
      </div>
      {/* bottom content 6 */}
      <div className="bottom-content-6">
        <div className="item-content-6">
          <a href="">
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/screenshot-2023-09-26-175445.jpg?v=1695725699413"
                alt="Simon and Schuster"
                title="Simon and Schuster"
              />
            </li>
          </a>
          <a href="">
            <p className="color-text-content-6">Simon and Schuster</p>
          </a>
        </div>
        <div className="item-content-6">
          <a href="">
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/screenshot-2023-09-26-093035.jpg?v=1695695448453"
                alt="Pop Up Projects"
                title="Pop Up Projects"
              />
            </li>
          </a>
          <a href="">
            <p className="color-text-content-6">Pop Up Projects</p>
          </a>
        </div>
        <div className="item-content-6-2 item-content-6">
          <a href="">
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/fireandwaterlogo-768x831.jpg?v=1695695322987"
                alt="HarperCollins Publishers"
                title="HarperCollins Publishers"
              />
            </li>
          </a>
          <a href="">
            <p className="color-text-content-6">HarperCollins Publishers</p>
          </a>
        </div>
        <div className="item-content-6-3 item-content-6">
          <a href="">
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/logo-goethe-institut.png?v=1694484225040"
                alt="Viện Goethe Hà Nội"
                title="Viện Goethe Hà Nội"
              />
            </li>
          </a>
          <a href="">
            <p className="color-text-content-6">Viện Goethe Hà Nội</p>
          </a>
        </div>
        <div className="item-content-6-4 item-content-6">
          <a href="">
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/logo.jpg?v=1694079471953"
                alt="Lotte Department Store Vietnam"
                title="Lotte Department Store Vietnam"
              />
            </li>
          </a>
          <a href="">
            <p className="color-text-content-6">
              Lotte Department Store Vietnam
            </p>
          </a>
        </div>
        <div className="item-content-6-5 item-content-6">
          <a href="">
            <li>
              <img
                src="https://bizweb.dktcdn.net/100/363/455/articles/penguin-random-house-svg.png?v=1694079204497"
                alt="Penguin Random House"
                title="Penguin Random House"
              />
            </li>
          </a>
          <a href="">
            <p className="color-text-content-6">Penguin Random House</p>
          </a>
        </div>
      </div>
    </div>
  </div>
  <footer className="footer">
    <div className="social-mk">
      <div className="grid wide">
        <div className="row">
          <div className="col l-4 m-12 c-12">
            <div className="social">
              <a
                href="https://www.facebook.com/nhanampublishing"
                className="social-btn"
                target="_blank"
              >
                <img
                  src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/facebook-icon.png?1704690471681"
                  alt=""
                  className="social-icon"
                />
              </a>
              <a
                href="https://www.instagram.com/"
                className="social-btn"
                target="_blank"
              >
                <img
                  src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/instagram-icon.png?1704690471681"
                  alt=""
                  className="social-icon"
                />
              </a>
              <a
                href="https://www.lazada.vn/shop/nha-nam-tphcm1632821525/"
                className="social-btn"
                target="_blank"
              >
                <img
                  src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/lazada-icon.png?1704690471681"
                  alt=""
                  className="social-icon"
                />
              </a>
              <a
                href="https://shopee.vn/nhanam59"
                className="social-btn"
                target="_blank"
              >
                <img
                  src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/shopee-icon.png?1704690471681"
                  alt=""
                  className="social-icon"
                />
              </a>
              <a
                href="https://www.tiktok.com/@nhanamhanoi"
                className="social-btn"
                target="_blank"
              >
                <img
                  src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/tiktok-icon.png?1704690471681"
                  alt=""
                  className="social-icon"
                />
              </a>
            </div>
          </div>
          <div className="col l-8 m-12 c-12">
            <div className="email">
              <h4 className="noti">Nhận thông tin khuyến mãi từ chúng tôi</h4>
              <div className="mail-noti">
                <form className="mail-form">
                  <input
                    type="email"
                    placeholder="Nhận email ưu đãi"
                    className="form-control"
                  />
                  <button type="submit" className="btn-submit">
                    Đăng kí
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="first-footer">
      <div className="grid wide">
        <div className="row">
          <div className="col l-3 m-6 c-12">
            <a href="" className="logo">
              <img
                src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/logo.png?1704690471681"
                alt=""
                style={{ height: "auto", width: "unset" }}
              />
              <span className="logo-title">Bởi vì sách là thế giới</span>
            </a>
            <ul className="list-1">
              <li className="list-content">
                <i
                  className="fa-light fa-location-dot icon-footer"
                  style={{ marginTop: 14 }}
                />
                <p style={{ marginBottom: 0, fontSize: 14 }}>
                  Số 59, Đỗ Quang, Trung Hoà, Cầu Giấy, Hà Nội.
                </p>
              </li>
              <li className="list-content">
                <i className="fa-light fa-envelope icon-footer" />
                <a href="" style={{ fontSize: 14 }}>
                  info@nhanam.vn
                </a>
              </li>
              <li className="list-content">
                <i className="fa-light fa-phone icon-footer" />
                <a href="" style={{ fontSize: 14 }}>
                  02435146876
                </a>
              </li>
              <li className="list-content">
                <i className="fa-light fa-mobile icon-footer" />
                <a href="" style={{ fontSize: 14 }}>
                  0903244248
                </a>
              </li>
            </ul>
          </div>
          <div className="col l-3 m-6 c-12">
            <h4 className="title-menu">giới thiệu</h4>
            <ul className="list-menu">
              <li className="li-menu">
                <a href="">Về Nhã Nam</a>
              </li>
              <li className="li-menu">
                <a href="">Hệ thống hiệu sách</a>
              </li>
              <li className="li-menu">
                <a href="">Hệ thống phát hành</a>
              </li>
              <li className="li-menu">
                <a href="">Tuyển dụng</a>
              </li>
              <li className="li-menu">
                <a href="">Liên hệ với chúng tôi</a>
              </li>
            </ul>
          </div>
          <div className="col l-3 m-6 c-12">
            <h4 className="title-menu">chính sách</h4>
            <ul className="list-menu">
              <li className="li-menu">
                <a href="">Chính sách bảo mật</a>
              </li>
              <li className="li-menu">
                <a href="">Chính sách đổi trả/hoàn tiền</a>
              </li>
              <li className="li-menu">
                <a href="">Chính sách thanh toán/ vận chuyển</a>
              </li>
            </ul>
          </div>
          <div className="col l-3 m-6 c-12">
            <h4 className="title-menu">phương thức thanh toán</h4>
            <div className="payment-method">
              <img
                src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/payment_method.png?1704690471681"
                alt=""
                style={{ height: "auto", width: "unset" }}
              />
            </div>
            <div className="payment">
              <a href="">
                <img
                  src="https://bizweb.dktcdn.net/100/363/455/themes/918830/assets/bocongthuong.png?1704690471681"
                  alt=""
                  style={{ height: "auto", width: "unset" }}
                />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
</>
  )
}
export default App